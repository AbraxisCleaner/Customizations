
  ____  ______ _______ _______ ______ _____            ______ _____   ______      _______  _____ _______       __   __
 |  _ \|  ____|__   __|__   __|  ____|  __ \     /\   |  ____|  __ \ / __ \ \    / /_   _|/ ____|__   __|/\    \ \ / /
 | |_) | |__     | |     | |  | |__  | |__) |   /  \  | |__  | |__) | |  | \ \  / /  | | | (___    | |  /  \    \ V / 
 |  _ <|  __|    | |     | |  |  __| |  _  /   / /\ \ |  __| |  _  /| |  | |\ \/ /   | |  \___ \   | | / /\ \    > <  
 | |_) | |____   | |     | |  | |____| | \ \  / ____ \| |____| | \ \| |__| | \  /   _| |_ ____) |  | |/ ____ \  / . \ 
 |____/|______|  |_|     |_|  |______|_|  \_\/_/    \_\______|_|  \_\\____/   \/   |_____|_____/   |_/_/    \_\/_/ \_\

Thanks for downloading! 

This is a modified version of AeroVistaX Reset, a theme made by NewInfinitePro. I did not make the full theme, they did.
This skin was made to look like Microsoft Windows Vista.
This was made to serve users of Microsoft Windows 10 with WindowBlinds 10 Installed.
Thank you Stardock for your wonderful program, thank you NewInfinitePro for making the OG theme, this wouldn't have been possible without you.
And thank you, the user reading this for checking out the theme. I hope you will like it.

Feel free to report any bugs in the comments section on the DeviantArt post.

Enjoy!
(VERSION COMPILED ON 6/10/2021 at 1:45PM MST)	

Changelog:
Version 1.0: June 2021 Summer Update
What's been added: Updated to the BetterAero7X 2.0 overhauled codebase.
What's been fixed:
1: Removed shine effect from toolwindows
2: Removed the flash effect from every single button type.
3: Ported accurate color palette from BetterAero7X 2.0.
Date 6/10/2021

Version 0.90: First public beta release
What's been added: Everything!
What's been fixed: Nothing.
Date:4/3/2021